module Aviator
  VERSION = "0.0.7"
end
