module Aviator
  VERSION = "0.2.1"
end
